const responses = {
    "hello": "Hello! How can I assist you today? 😊",
    "hi": "Hey there! How are you feeling today?",
    "how are you": "I'm a bot, but I'm here to chat with you! How about you?",
    "sad": "I'm sorry you're feeling this way. Remember, you're not alone. 💙",
    "happy": "That's awesome! Keep spreading positivity! 🌟",
    "bye": "Goodbye! Take care and stay positive! 😊",
    "default": "I'm still learning. Can you tell me more?"
};

function sendMessage() {
    let userInput = document.getElementById("user-message").value.trim().toLowerCase();
    if (userInput === "") return;

    addMessage(userInput, "user");

    let botResponse = responses[userInput] || responses["default"];

    setTimeout(() => {
        addMessage(botResponse, "bot");
    }, 800);

    document.getElementById("user-input").value = "";
}

function handleKeyPress(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
}

function addMessage(text, sender) {
    let chatBox = document.getElementById("chat-box");
    let messageElement = document.createElement("div");
    messageElement.classList.add("message", sender);
    messageElement.textContent = text;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;
}